<h1>Tag <i><?php echo $tag; ?></i></h1>
<p>Hello!<br/>
This is a basic show action for tag module. To actually show what probably
you'll need here, just overwrite it in your app.</p>
