<?php

class BaseExtendMe
{
}
