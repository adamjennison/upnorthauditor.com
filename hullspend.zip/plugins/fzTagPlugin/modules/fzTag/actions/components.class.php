<?php

/**
 * Components class to service tag lists
 * @author fizyk
 */
require_once dirname(__FILE__).'/../lib/BasefzTagComponents.class.php';
class fzTagComponents extends BasefzTagComponents
{

}
