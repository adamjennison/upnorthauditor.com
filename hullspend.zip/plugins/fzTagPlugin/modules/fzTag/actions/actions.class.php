<?php
/**
 * Description of fzTagActions
 *
 * @author fizyk
 */
require_once dirname(__FILE__).'/../lib/BasefzTagActions.class.php';
class fzTagActions extends BasefzTagActions
{
    //put your code here
}
?>
