<div class="component_<?php echo isset($varParam) ? $varParam : '' ?>_<?php echo isset($componentParam) ? $componentParam : '' ?>_<?php echo isset($requestParam) ? $requestParam : '' ?>">OK</div>
