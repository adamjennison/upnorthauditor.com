<sentences>
  <?php echo $sf_content ?>
</sentences>
