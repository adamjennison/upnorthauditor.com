<ul id="products">
  <?php foreach ($products as $product): ?>
    <li class="toString"><?php echo $product ?></li>
  <?php endforeach; ?>
</ul>
