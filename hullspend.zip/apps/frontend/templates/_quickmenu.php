<h1 class='logo'>
          Hull City Council - Armchair Auditor Clone
</h1>
<div class='noprint' id='nav'>
<?php echo link_to('Home','/library/web/hullspend') ?>
<?php echo link_to('Suppliers','/library/web/hullspend/suppliers') ?>
<?php echo link_to('Directorates','/library/web/hullspend/directorates') ?>
<?php echo link_to('Services','/library/web/hullspend/services') ?>
<?php //echo link_to('Top10','/library/web/hullspend/top10') ?>
<?php echo link_to('About','/library/web/hullspend/about') ?>
</div>
