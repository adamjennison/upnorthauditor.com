<?php echo $sf_params->get('filter') ?>
