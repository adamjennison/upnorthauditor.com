<?php

require_once dirname(__FILE__).'/../lib/fzTagAdminGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/fzTagAdminGeneratorHelper.class.php';

/**
 * fzTagAdmin actions.
 *
 * @package    PluginsPlayground
 * @subpackage fzTagAdmin
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class fzTagAdminActions extends autoFzTagAdminActions
{
}
