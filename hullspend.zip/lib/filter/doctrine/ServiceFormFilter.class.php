<?php

/**
 * Service filter form.
 *
 * @package    myshelf
 * @subpackage filter
 * @author     Adam Jennison
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ServiceFormFilter extends BaseServiceFormFilter
{
  public function configure()
  {
  }
}
