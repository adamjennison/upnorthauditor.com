<div class="sf_admin_form_row sf_admin_text sf_admin_form_field_reportUsage">
<div>
<label><?php echo __('Weight') ?></label>
<div class="content">
    <?php echo $form->getObject()->getWeight() ?>
</div>
</div>
</div>