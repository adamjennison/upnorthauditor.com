<hr/>
<div id='footer'>
  <p>
    This website has no affiliation what so ever with <?php echo link_to('Hull City Council','http://www.hullcc.gov.uk') ?><br/>
    Code based on the <?php echo link_to('original design and idea','http://armchairauditor.co.uk/')?> by <a href='http://twitter.com/adrianshort'>Adrian Short</a><br/>
  
    Thanks go to Adrian for opening his code to the wider World, if you love it - set it free.<br/>
    Powered by <?php echo link_to('Symfony 1.4','http://www.symfony-project.org/') ?>
    You can contact me any time via admin@upnorthauditor.com
  </p>
</div>
